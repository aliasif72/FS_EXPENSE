const express=require('express');
const bodyParser = require('body-parser');
const jwt=require('jsonwebtoken');
const sequelize = require('./util/database');
//const errorController = require('./controllers/error');
const cors=require('cors');
const userRoutes=require('./route/user');
const expenseRoute=require('./route/expense');
const User=require('./model/user');
const Expense=require('./model/expense');
const app= express();

app.use(cors());
app.use(bodyParser.json());
app.use('/user', userRoutes);
app.use('/user/login',expenseRoute);

User.hasMany(Expense,{constraints :true , onDelete:'Cascade'});
Expense.belongsTo(User);
sequelize
.sync()
.then(   app.listen(3000,()=>console.log("server is ON")))
.catch(err=>console.log(err));