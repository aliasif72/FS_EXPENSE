const Razorpay=require('razorpay');
const Order=require('../model/razor');
require ("dotenv").config();

exports.buypremium=(req,res,next)=>
{
    try{
        var rzp=new Razorpay({
            key_id : process.env.RAZORPAY_KEY_ID,
            key_secret : process.env.RAZORPAY_KEY_SECRET
        })
        
        rzp.orders.create({amount:2500,currency:"INR"}, (err,order)=>
    {
        if(err)
        {
            throw new Error(JSON.stringify(err));
        }
        console.log(order);
        req.user.createOrder({orderId:order.id, status: 'PENDING'})
        .then(()=>
        {
            console.log( rzp.key_id);
            return res.status(201).json({order, key_id : rzp.key_id});
    }) 
    .catch((err)=>
        {
            throw new Error(err);   
        })
    })}
        catch(err)
         {
        console.log(err);
        res.status(403).json({ message: 'something went wrong', error:err})
    }
         }

         exports.updatestatus=  async (req,res,next)=>
         {
            try
            {console.log(40);
            const{payment_id, order_id}= req.body;
            const order= await Order.findOne({where:{ orderId:order_id}})
            const promise1 = order.update({paymentid: payment_id, status: 'SUCCESS'});
            const promise2 =req.user.update({isPremium: true});
            Promise.all([promise1,promise2]).then(()=>
            {
                return res.status(202).json({success:true, message:'Transaction Successful'});
            })
            .catch((err)=>
            {
                throw new Error(err);
            })
         }
         catch(err)
         {
            res.status(404).json({error:err, message: 'Something went wrong'});
         }
        }
      