const express=require('express');


const router=express.Router();
const razorController= require('../controller/razor');
const middle=require('../midleware/auth');

router.get('/premium', middle.authenticate, razorController.buypremium);
router.post('/updatestatus', middle.authenticate, razorController.updatestatus);
module.exports=router;