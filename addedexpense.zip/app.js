const express=require('express');
const bodyParser = require('body-parser');
const sequelize = require('./util/database');
//const errorController = require('./controllers/error');
const cors=require('cors');
const userRoutes=require('./route/user');
const expenseRoute=require('./route/expense');

const app= express();

app.use(cors());
app.use(bodyParser.json());
app.use('/user', userRoutes);
app.use('/user/login',expenseRoute);

sequelize
.sync()
.then(   app.listen(3000,()=>console.log("server is ON")))
.catch(err=>console.log(err));