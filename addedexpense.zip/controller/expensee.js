const Expense=require('../model/expense');

exports.addExpense= (req,res,next)=>{
const category=req.body.category;
const price=req.body.amount;
const description=req.body.description;

Expense.create({
    category:category,
    amount:price,
    description:description
})
.then((result)=>res.status(200).json((result)))
.catch(err=>console.log(err));
}

exports.getExpenseByPk = async(req,res,next)  =>{
  try{
   let result= await Expense.findAll();
    res.status(200).send(result); 
     }
    catch(err)
         {
          console.log(err);
         }
            }

exports.editExpense= async(req,res,next)=>{
   const id=req.params.Nid;
    const category=req.body.category;
    const price=req.body.amount;
    const description=req.body.description; 
   await Expense.findByPk(id)   
    .then((data)=>
    {
         data.category=category;
        data.amount=price;
        data.description=description;
        return data.save();
    })
    .then(result=>
        {
          res.status(200).json((result));
        })
    .catch(err=>console.log(err));
    }

 exports.getExpense = async(req,res,next)  =>{
  try{
   let result= await Expense.findAll();
    res.status(200).json(result); 
     }
    catch(err)
         {
          console.log(err);
         }
            }
   

  exports.deleteExpense= (req,res,next)=>{
    const idd=req.params.Nid;    
                                                      //  Info.findByPk(idd)
            Expense.destroy({ where: { Id: idd} })   //.then(product=> 
                                                  //  {return product.destroy()})
                                                  //.then(result=>
                                                  //{console.log("deleted");
            .then((result)=>res.status(200).send('deleted'))
             .catch(err=>console.log(err));
             }