const Expense=require('../model/expense');
const jwt=require('jsonwebtoken');

exports.addExpense= (req,res,next)=>{
const category=req.body.category;
const amount=req.body.amount;
const description=req.body.description;

req.user.createExpense({
category,
amount,
description
})

//                                          Expense.create({
//                                           category,
//                                             amount,
//                                           description,      
//                                           user1Id:req.user.Id
//                                                })
.then((result)=>{
  console.log(result);
  res.status(200).json(result);
})
.catch(err=>console.log(err));
}

exports.getExpenseByPk = async(req,res,next)  =>{
  try{
    const id=req.header('authorization');
     let result= await Expense.findByPk(id);
       res.status(200).json(result); 
     }
    catch(err)
         {
          console.log(err);
         }
            }

exports.editExpense= async(req,res,next)=>{
   const ide=req.params.Nid;
    const category=req.body.category;
    const price=req.body.amount;
    const description=req.body.description; 
   await Expense.findByPk(ide)   
    .then((data)=>
    {
         data.category=category;
        data.amount=price;
        data.description=description;
        return data.save();
    })
    .then(result=>
        {
          res.status(200).json((result));
        })
    .catch(err=>console.log(err));
    }

 exports.getExpense = async(req,res,next)  =>{
  try{
       let result=await req.user.getExpenses()
       res.status(200).json(result); 
     }
    catch(err)
         {
          console.log(err);
         }
            }
   
  exports.deleteExpense= (req,res,next)=>{
    const idd=req.params.Nid;    
                                                      //  Info.findByPk(idd)
            Expense.destroy({ where: { Id: idd, user1Id: req.user.id} })   //.then(product=> 
                                                  //  {return product.destroy()})
                                                  //.then(result=>
                                                  //{console.log("deleted");
            .then((result)=>res.status(200).send('deleted'))
             .catch(err=>console.log(err));
             }