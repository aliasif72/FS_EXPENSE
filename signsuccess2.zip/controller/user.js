const User1=require('../model/user');

exports.signup=async (req,res,next)=>
{
    const { name,email,password } = req.body;
     await User1.findOne({where:{email:email}})
      .then(exist=> 
        {
              if(exist)
    {
        console.log("failed");
         return res.status(403).json("User already exist!!");
    }
    User1.create({
       name:name,
        email:email,
        password:password
    })
    .then(resp=>res.status(201).json("Sign up successful!!"));
})}