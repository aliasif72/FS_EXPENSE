const User1=require('../model/user');
const bcrypt=require('bcrypt');

exports.signup=async (req,res,next)=>
{
    const { name,email,password } = req.body;
    const exist= await User1.findOne({where:{email:email}})
       if(exist)
    {
        console.log("failed");
         return res.status(403).json("User already exist!!");
    }
    const saltRounds=10;
    bcrypt.hash(password,saltRounds,(err,hash)=>
    {
     User1.create({
       name:name,
        email:email,
        password:hash
    })
   .then(resp=>res.status(201).json("Sign up successful!!"))
    .catch(err=>console.log(err));
})
}

    

exports.login = async(req,res,next)=>
{
    const {email,password } = req.body;
    await User1.findAll({where:{email:email}})
   .then(exist=>
    {
        if(exist[0]==undefined)//or(exist.length>1) so, yaha pe exist=[], exist[0]=undefined dega console krne pe
        {
            return res.status(404).json("User doesn't exist");
        }
        bcrypt.compare(password,exist[0].password,(err,result)=>{
          if(result)
          {
            return res.status(201).json("Login success");
          }
          return res.status(401).json("User not authorized");
        });
    })
    .catch(err=>console.log(err));
}